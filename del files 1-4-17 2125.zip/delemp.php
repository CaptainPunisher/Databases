<?php
require_once ('dbindex.php'); 
echo '<h1>Delete an existing employee</h1>';

echo "<br><br><h3>Which employee would you like to delete?</h3>";
echo "<font color='red'>Please enter name string to search<br>Leave blank to show all</font><br><br>";




?>

<!DOCTYPE HTML>
<html>  
<body>

<form action="delemp2.php" method="post">
Name: 		<input type="text" name="name"><br>


<input type="submit" value='SUBMIT'>
</form>

</body>
</html>